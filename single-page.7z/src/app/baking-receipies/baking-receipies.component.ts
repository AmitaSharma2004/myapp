import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baking-receipies',
  templateUrl: './baking-receipies.component.html',
  styleUrls: ['./baking-receipies.component.css']
})
export class BakingReceipiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
