import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-recipes',
  templateUrl: './popular-recipes.component.html',
  styleUrls: ['./popular-recipes.component.css']
})
export class PopularRecipesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
