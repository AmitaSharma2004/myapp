import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-for-you',
  templateUrl: './recipe-for-you.component.html',
  styleUrls: ['./recipe-for-you.component.css']
})
export class RecipeForYouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
